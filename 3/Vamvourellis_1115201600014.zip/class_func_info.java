import java.util.*;

public class class_func_info{
  // argument names, argument types
  public LinkedHashMap<String, String> args = new LinkedHashMap<String, String>();
  // variable names, vaviable types
  public LinkedHashMap<String, String> vars = new LinkedHashMap<String, String>();
  public String return_type = "";
}
